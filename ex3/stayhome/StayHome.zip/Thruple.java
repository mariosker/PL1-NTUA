public class Thruple {
    public int y;
    public int x;
    public int time;

    public Thruple(int y, int x, int time) {
        this.x = x;
        this.y = y;
        this.time = time;
    }
}
